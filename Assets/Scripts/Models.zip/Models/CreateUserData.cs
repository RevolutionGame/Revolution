﻿using System;

namespace modelSpace {

    [System.Serializable]
    public class CreateUserData
    {
        public string error;
        public string msg;
        public UserData data;

    }

}

