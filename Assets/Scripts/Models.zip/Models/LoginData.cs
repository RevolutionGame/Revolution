﻿using System;
namespace modelSpace
{
    [System.Serializable]
    public class LoginData
    {

        public string msg;
        public string error;
        public UserData data;


    }
}
