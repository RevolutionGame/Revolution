﻿using System;
namespace modelSpace
{
    [System.Serializable]
    public class UserData
    {
        public int id;
        public string name;
        public string username;
        public string cell_number;
        public string email;

    }
}
